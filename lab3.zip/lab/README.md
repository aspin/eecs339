# simple-db-hw

## Style Justifications
(blah blah)

Using Java 8 (source1.=8 in build.xml)

Byte.toUnsignedInt
filter


## more stuff
ant runtest -Dtest=
ant runsystest -Dtest=
